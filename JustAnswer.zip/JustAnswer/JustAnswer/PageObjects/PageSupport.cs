﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using JustAnswer.PageObjects;
using JustAnswer.TestCases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustAnswer
{
    public static class PageSupport
    {
        public static IWebDriver WebDriver;
        private static T GetPage<T>() where T : new()
        {
            var page = new T();
            PageFactory.InitElements(BrowserData.Driver, page);
            return page;
        }
       
        public static HomePage Homepage => GetPage<HomePage>();

        public static PaymentPage PaymentPage => GetPage<PaymentPage>();





    }
}
