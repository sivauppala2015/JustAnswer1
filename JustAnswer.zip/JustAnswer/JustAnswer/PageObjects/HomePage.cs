﻿using AventStack.ExtentReports;
using JustAnswer.TestCases;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace JustAnswer.PageObjects
{
    public class HomePage : Base_TestSetUp
    {

     

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div[2]/div[1]/div/div/div[3]/div/div/textarea")]
        
        public IWebElement txtChatMsg { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div[2]/div[1]/div/div/div[2]/div[2]/div/div[1]/div[11]/div/a")]
        public IWebElement lnkContinue { get; set; }        

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div[2]/div[2]/div[7]/div/div/div/div[2]/div[1]/a")]
        public IWebElement lnkQues { get; set; }       

        [FindsBy(How = How.XPath, Using = "//*[@id='expert_thread_2']/div[2]/div[4]/div[2]")]
        public IWebElement btnAskurQues { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[7]/div[1]/div[4]/div/textarea")]
        public IWebElement txtChat2Msg { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[7]/div[1]/div[3]/div[1]/div[9]/div/a")]
        public IWebElement lnkContinue2 { get; set; }

       


    }
}