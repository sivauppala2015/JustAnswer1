﻿using AventStack.ExtentReports;
using JustAnswer.TestCases;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace JustAnswer.TestCases
{
    public class PaymentPage : Base_TestSetUp
    {

       

        [FindsBy(How = How.Id, Using = "input-email")]
        public IWebElement txtMailid { get; set; }

        [FindsBy(How = How.Id, Using = "input-card-number")]
        public IWebElement txtCardNumber { get; set; }

        [FindsBy(How = How.Id, Using = "card-dateinput")]
        public IWebElement txtMMYY { get; set; }

        [FindsBy(How = How.Id, Using = "input-card-cvv")]
        public IWebElement txtCVVNumber { get; set; }

        [FindsBy(How = How.Id, Using = "input-card-zip")]
        public IWebElement txtZip { get; set; }
        
             [FindsBy(How = How.Id, Using = "cta-form-submit")]
        public IWebElement btnSubmit { get; set; }

        

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[2]/div[1]/div[1]")]
        public IWebElement srcPage { get; set; }


        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[2]/div[1]/div[1]/div[2]/div/div[1]/div/div[3]/div/p[2]")]
        public IWebElement lbErr4InvalidCcNum { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[2]/div[1]/div[1]/div[2]/div/div[1]/div/div[2]/div/p[2]")] 
        public IWebElement lbErrMsg4InvalidMail { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[2]/div[1]/div[1]/div[2]/div/div[1]/div/div[4]/div/div[1]/div/p[2]")]
        public IWebElement lbErrMsg4InvalidDate { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[2]/div[1]/div[1]/div[2]/div/div[1]/div/div[4]/div/div[1]/div/p[2]")]
        public IWebElement lbErr4CcExpire { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[2]/div[1]/div[1]/div[2]/div/div[1]/div/div[4]/div/div[2]/div/p[2]")]
        public IWebElement lbErrMsg4InvalidCvv { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[2]/div[1]/div[1]/div[2]/div/div[1]/div/div[4]/div/div[3]/div/p[2]")]
        public IWebElement lbErrMsg4emptyZip { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[2]/div[1]/div[1]/div[2]/div/div[1]/div/div[3]/div/p[2]")]
        public IWebElement lbErrMsg4emptyCcNum { get; set; }



        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[1]/div/div[2]/div/div/div[1]/div[1]/div[2]/div[1]/p[2]")]
        public IWebElement lbErr4InvalidCcNum2 { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[1]/div/div[2]/div/div/div[1]/div[1]/div[2]/div[2]/p[2]")]
        public IWebElement lbErrMsg4InvalidCvv2 { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[1]/div/div[2]/div/div/div[1]/div[1]/div[2]/div[3]/p[2]")]
        public IWebElement lbErrMsg4InvalidZip2 { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[1]/div/div[2]/div/div/div[1]/div[1]/div[3]/div[1]/p[2]")]
        public IWebElement lbErrMsg4MMYY2 { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[1]/div/div[1]/div[2]/div/div[1]/div/div[2]/div/div/div[1]/div[1]/div[3]/div[2]/p[2]")]
        public IWebElement lbErrMsg4InvalidMail2 { get; set; }

      








    }
}