﻿
using AventStack.ExtentReports;
using System;

namespace JustAnswer.TestCases
{
    public class ExtentManager
    {
        private static readonly Lazy<ExtentReports> Extent = new Lazy<ExtentReports>(() => new ExtentReports());

        public static ExtentReports GetSupport
        {
             
            get
            {
                return Extent.Value;
            }

        }

        private ExtentManager() { }
    }
}