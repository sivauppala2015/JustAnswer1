﻿using AventStack.ExtentReports;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Reporter.Configuration;
using NUnit.Framework.Interfaces;
using System.IO;
using OpenQA.Selenium.Chrome;
using System.Reflection;

namespace JustAnswer.TestCases
{
    [TestFixture]
    public class ExtentReport
    {
        public ExtentReports ExtentReporter = ExtentManager.GetSupport;
        public ExtentV3HtmlReporter htmlReporter;
        public ExtentTest Report;
        public IWebDriver JustDriver;     
        private static bool singleCounter;
        public static string resultRootPath;

    public void GenerateReport()
        {
            var status = TestContext.CurrentContext.Result.Outcome.Status;
            var stackTrace = "" + TestContext.CurrentContext.Result.StackTrace + "";
            var errorMessage = TestContext.CurrentContext.Result.Message;
            string path = Projectpath();                  
            string screenshotpath = $"{resultRootPath}{"\\Screenshots\\"}";           

            if (status == TestStatus.Failed)
            {               
                path = $"{screenshotpath}{"FAIL_"}{GetDate()}{".jpeg"}";
                ITakesScreenshot objectScreen = (ITakesScreenshot)JustDriver;
                Screenshot screenCapture = objectScreen.GetScreenshot();
                screenCapture.SaveAsFile(path, ScreenshotImageFormat.Jpeg);

                Report.Log(Status.Fail, status + errorMessage);
                Report.Log(Status.Fail, stackTrace + errorMessage);
                MediaEntityBuilder.CreateScreenCaptureFromPath(path).Build();
                Report.AddScreenCaptureFromPath(path);
                Report.Log(Status.Fail, status.ToString());

            }
            else if(status == TestStatus.Passed)
            {               
                path = $"{screenshotpath}{"PASS_"}{GetDate()}{".jpeg"}";
                ITakesScreenshot objectScreen = (ITakesScreenshot)JustDriver;
                Screenshot screenCapture = objectScreen.GetScreenshot();
                screenCapture.SaveAsFile(path, ScreenshotImageFormat.Jpeg);
                MediaEntityBuilder.CreateScreenCaptureFromPath(path).Build();
                Report.AddScreenCaptureFromPath(path);
                Report.Log(Status.Pass, status.ToString());

            }
            else
            {
                path = $"{screenshotpath}{"Unknown_"}{GetDate()}{".jpeg"}";
                ITakesScreenshot objectScreen = (ITakesScreenshot)JustDriver;
                Screenshot screenCapture = objectScreen.GetScreenshot();
                screenCapture.SaveAsFile(path, ScreenshotImageFormat.Jpeg);
                Report.Log(Status.Error, status + errorMessage);
                Report.Log(Status.Error, stackTrace + errorMessage);
                MediaEntityBuilder.CreateScreenCaptureFromPath(path).Build();
                Report.AddScreenCaptureFromPath(path);
                Report.Log(Status.Error, status.ToString());

            }

           

        }
    public void SetupReporting()
        {

            if (singleCounter == false)
            {
                string reportPath = GetFolderLocation();              
                string  path = $"{reportPath}{"\\Screenshots\\"}";
            if (!Directory.Exists(path))
            {
                    System.IO.Directory.CreateDirectory(path);

            }
             
           
           string htmlreportPath = $"{reportPath}{"\\TestResults_"}{GetDate()}{".html"}";
               
            htmlReporter = new ExtentV3HtmlReporter(htmlreportPath);         
            htmlReporter.Config.Theme = Theme.Standard;
            htmlReporter.Config.DocumentTitle = "TestAutomation";
                htmlReporter.Config.ReportName = "SIEMENS Automation Test Reusults";
               
            ExtentReporter.AttachReporter(htmlReporter);
            ExtentReporter.AddSystemInfo("Host Name", System.Net.Dns.GetHostName());
            ExtentReporter.AddSystemInfo("Environment", "QA");
            ExtentReporter.AddSystemInfo("Username", System.Security.Principal.WindowsIdentity.GetCurrent().Name);
               
            singleCounter = true;
            resultRootPath = reportPath;
                
        }
           

        }
    public string Projectpath()
    {
        string pth = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
        string actualPath = pth.Substring(0, pth.LastIndexOf("bin"));
        string projectPath = new Uri(actualPath).LocalPath;
        return projectPath;
    }
    public string GetDate()
    {
        string random = DateTime.Now.ToString();
        random = random.Replace('/', ' ').Replace(':', ' ').Replace('-', ' ').Replace(' ', '_').Trim();

        return random;
    }
    public string GetFolderLocation(bool screenShotFlag = false)
    {
        string random = GetDate();
        string reportPath = Projectpath();
        if (!screenShotFlag)
        {
            reportPath = $"{reportPath}{"TestResults\\"}{"TestResults_"}{random}";
            System.IO.Directory.CreateDirectory(reportPath);
        }
        else
        {
            reportPath = $"{reportPath}{"TestResults\\"}{random}";
            System.IO.Directory.CreateDirectory(reportPath);
        }
        return reportPath;
    }
   
    public int GetSerialNumber(string path)
    {
        System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(path);
        int count = dir.GetFiles().Length;
        return count + 1;

    }
  
    }
}

