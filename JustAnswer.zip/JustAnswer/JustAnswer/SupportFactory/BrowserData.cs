﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System;
using System.Collections.Generic;
using NUnit.Framework;
using NUnit.Framework.Interfaces;


namespace JustAnswer.TestCases
{
    [TestFixture]
    public class BrowserData
    {
        private static readonly IDictionary<string, IWebDriver> Drivers = new Dictionary<string, IWebDriver>();
        private static IWebDriver JustDriver;

        public static IWebDriver Driver
        {
            get
            {
                if (JustDriver == null)
                    throw new NullReferenceException("The WebDriver browser instance was not initialized. You should first call the method InitBrowser.");
                return JustDriver;
            }
            private set
            {
                JustDriver = value;
            }
        }

        public static void InitBrowser(string browserName)
        {
            switch (browserName)
            {
                case "Firefox":
                    if (JustDriver == null)
                    {
                        JustDriver = new FirefoxDriver();
                        Drivers.Add("Firefox", JustDriver);
                        JustDriver.Manage().Window.Maximize();

                    }
                    break;

                case "IE":
                    if (JustDriver == null)
                    {
                        JustDriver = new InternetExplorerDriver();
                        Drivers.Add("IE", JustDriver);
                        JustDriver.Manage().Window.Maximize();

                    }
                    break;

                case "Chrome":
                    if (JustDriver == null)
                    {
                        var service = ChromeDriverService.CreateDefaultService();
                        JustDriver = new ChromeDriver(service);
                        Drivers.Add("Chrome", JustDriver);
                        JustDriver.Manage().Window.Maximize();

                       

                    }

                    break;

            }
        }

        public static void LoadApplication(string url)
        {
            JustDriver.Url = url;
        }

        public static void CloseAllDrivers()
        {
            foreach (var key in Drivers.Keys)
            {
                Drivers[key].Close();
                Drivers[key].Quit();
            }
        }
        public static Func<IWebDriver, bool> ElementIsVisible(IWebElement element)
        {
            return (driver) =>
            {
                try
                {
                    return element.Displayed;
                }
                catch (Exception)
                {
                    // If element is null, stale or if it cannot be located
                    return false;
                }
            };
        }

    }
}