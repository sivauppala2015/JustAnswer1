﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Configuration;
using AventStack.ExtentReports.Reporter;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support;
using JustAnswer;
using System;
using System.Collections.Generic;
using System.Configuration;


namespace JustAnswer.TestCases
{

    [TestFixture]
    public class Base_TestSetUp : ExtentReport
    {
      
        [SetUp]
        public void Initializations()
        {
            driverInitialization();
          
        }
        
       
        [OneTimeSetUp]
        public void InitiateReport()
        {
            SetupReporting();  
            
        }

        [TearDown]
        public void CloseActions()
        {
            GenerateReport();
            closeDriver();
            placeReport();

        }

        public void closeDriver()
        {
            BrowserData.CloseAllDrivers();
        }

        public void placeReport()
        {
            ExtentReporter.Flush();
        }

        public void driverInitialization()
        {

            BrowserData.InitBrowser("Chrome");
            BrowserData.LoadApplication(System.Configuration.ConfigurationManager.AppSettings["URL"]);
            JustDriver = BrowserData.Driver;
        }


    }

}

