﻿using AventStack.ExtentReports;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using JustAnswer.PageObjects;
using JustAnswer.TestCases;
using System;
using System.Threading;

namespace JustAnswer.TestCases
{
    
    [TestFixture]
    public class Assignments : Base_TestSetUp
{
        
        [Test]
        public void Scenario_1()
        {
            int n=4;
            string errMsg;
            WebDriverWait Wait = new WebDriverWait(JustDriver, TimeSpan.FromSeconds(10));
            Report = ExtentReporter.CreateTest("Feature 1 : TC1 ");
            Report.Log(Status.Info, "Entering Text in ChatMessger");
            for (int i = 0; i < n; i++)
            {
               
                    PageSupport.Homepage.txtChatMsg.SendKeys("Thanks for Test");
                    PageSupport.Homepage.txtChatMsg.SendKeys(Keys.Enter);

                JustDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
                Thread.Sleep(10000);
                
            }
            Report.Log(Status.Info, "Click on Continue Link");
              Wait.Until(BrowserData.ElementIsVisible(PageSupport.Homepage.lnkContinue));            
              PageSupport.Homepage.lnkContinue.Click();

            Report.Log(Status.Info, "Enter Invalid Mail id and click on Start Your Trail button");
            PageSupport.PaymentPage.txtMailid.SendKeys("Dummy");
            PageSupport.PaymentPage.btnSubmit.Submit();

            Report.Log(Status.Info, "Validation of Six Messages as per Requirement");
            errMsg = PageSupport.PaymentPage.lbErrMsg4InvalidMail.Text.ToLower();
            Assert.AreEqual(errMsg.Contains("it looks like you entered an email address that doesn’t exist. please try re-entering."), true);

            errMsg = PageSupport.PaymentPage.lbErrMsg4emptyCcNum.Text.ToLower();
            Assert.AreEqual(errMsg.Contains("you must enter a credit card number."), true);

            errMsg = PageSupport.PaymentPage.lbErrMsg4InvalidDate.Text.ToLower();
            Assert.AreEqual(errMsg.Contains("enter an expiration date."), true);

            errMsg = PageSupport.PaymentPage.lbErrMsg4InvalidCvv.Text.ToLower();
            Assert.AreEqual(errMsg.Contains("enter security code."), true);

            errMsg = PageSupport.PaymentPage.lbErrMsg4emptyZip.Text.ToLower();
            Assert.AreEqual(errMsg.Contains("enter zip/postal code"), true);


            PageSupport.PaymentPage.txtCardNumber.SendKeys("invalidCard");

            errMsg = PageSupport.PaymentPage.lbErr4InvalidCcNum.Text.ToLower();
            Assert.AreEqual(errMsg.Contains("the credit card number is invalid"), true);


        }
       
        [Test]
        public void Scenario_3()
        {
            int n = 4;
            string errMsg;
            WebDriverWait Wait = new WebDriverWait(JustDriver, TimeSpan.FromSeconds(10));
            Report = ExtentReporter.CreateTest("Feature 1 : TC1 ");
            Report.Log(Status.Info, "Click on First Question");
            PageSupport.Homepage.lnkQues.Click();
            Thread.Sleep(10000);

            PageSupport.Homepage.btnAskurQues.Click();

            for (int i = 0; i < n; i++)
            {

                PageSupport.Homepage.txtChat2Msg.SendKeys("Thanks for Test2");
                PageSupport.Homepage.txtChat2Msg.SendKeys(Keys.Enter);

                JustDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
                Thread.Sleep(10000);

            }
            Report.Log(Status.Info, "Click on Continue Link");
            Wait.Until(BrowserData.ElementIsVisible(PageSupport.Homepage.lnkContinue2));            
            PageSupport.Homepage.lnkContinue2.Click();

            Report.Log(Status.Info, "Enter Invalid Card number click on Start My Trail button");
            PageSupport.PaymentPage.txtCardNumber.SendKeys("InvalidCard");
            PageSupport.PaymentPage.btnSubmit.Submit();

            Report.Log(Status.Info, "Validation of Six Messages as per Requirement");
            errMsg = PageSupport.PaymentPage.lbErr4InvalidCcNum2.Text.ToLower();
            Assert.AreEqual(errMsg.Contains("the credit card number is invalid"), true);

            errMsg = PageSupport.PaymentPage.lbErrMsg4InvalidCvv2.Text.ToLower();
            Assert.AreEqual(errMsg.Contains("enter security code."), true);

            errMsg = PageSupport.PaymentPage.lbErrMsg4InvalidZip2.Text.ToLower();
            Assert.AreEqual(errMsg.Contains("enter zip/postal code."), true);

            errMsg = PageSupport.PaymentPage.lbErrMsg4MMYY2.Text.ToLower();
            Assert.AreEqual(errMsg.Contains("select an expiration date."), true);

            errMsg = PageSupport.PaymentPage.lbErrMsg4InvalidMail2.Text.ToLower();
            Assert.AreEqual(errMsg.Contains("enter your email address"), true);



          

        }



    }

 
}
